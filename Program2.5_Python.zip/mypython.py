#Program Name: Python Exploration 
#Author: Andrew Victor
#Date: November 1st, 2019

import os
import string
import uuid
import random 

#Function that will generate random strings for the files 
def GenerateString(string_length=10):
	randomStr = string.ascii_lowercase 
	return ''.join(random.choice(randomStr) for i in range(string_length))

#Function that will create the files and add them to the directory 
def GenerateFiles():
	#Make files 
	f1= open("File1", "w")
	f2= open("File2", "w")
	f3= open("File3", "w")

	#Make the random strings 
	str1 = GenerateString()
	str2 = GenerateString()
	str3 = GenerateString()
	str4 = ("\n")

	#Write the random strings to the files 
	f1.write(str1+str4)
	f2.write(str2+str4)
	f3.write(str3+str4)

	#Close the files 
	f1.close()
	f2.close()
	f3.close()

GenerateFiles() 

#Function that will read the generated files 
def ReadFiles(): 
	#Read the files and print them 
	f1= open("File1", "r")
	print f1.read(10)
	f2= open("File2", "r")
	print f2.read(10)
	f3= open("File3", "r")
	print f3.read(10)

ReadFiles()

#Function that will write random numbers to the screen 
def WriteNumbers(): 
	#Generate a random number, then print it
	r1 = random.randint(1, 42)
	print(r1)
	r2 = random.randint(1, 42)
	print(r2)
	r3 = r1*r2
	print(r3)

WriteNumbers() 
