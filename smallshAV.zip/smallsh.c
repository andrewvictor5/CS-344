/*
** Programming Assignment 3
** File: smallsh
** Author: Andrew Victor
** Date: November 17th, 2019
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <limits.h>
#include <fcntl.h>
#include <time.h>

//Define global variables to represent max number of chars and lines
#define MAX_CHARACTERS 2048
#define MAX_ARGUMENTS 512

int foreground;

//This function will catch SIGTSTP signals
//Will change to foreground only mode if necessary
void catchSIGTSTP(int sigNum) {
	
	if(foreground == 0) {
		//foreground = 1;
		char* error = "SIGTSTP Error Caught\nEntering Foreground Only Mode\nThe '&' will be ignored\n";
		write(STDOUT_FILENO, error, 100);
		fflush(stdout);
		foreground = 1;
	}
	else { 
		char* error = "Exiting Foreground Only Mode\n";
		write(STDOUT_FILENO, error, 50);
		fflush(stdout);
		foreground = 0;  
	}
}

//This function will get the input from the user
//The function will return the line entered by the user
//Modeled from code provide in required readings for block 3
char* GetUserInput() {

	//Initialize variables to be used in getline()
	int numCharacters = -5;
	int currentCharacter = -5;
	size_t bufferSize = 0;
	char* line = NULL;

	while(1) {
		
		while(1) {

			//Print required format for assignment and flush stdout
			printf(": ");
			fflush(stdout);
			numCharacters = getline(&line, &bufferSize, stdin);
			
			//Error handling in case something goes wrong
			if(numCharacters == -1) {
				clearerr(stdin);
			}
			
			else {
				//Break means that we have the line and are ready to move on
				break;
			}
		}	
		
		//Get rid of the \n that getline() adds
		line[strcspn(line, "\n")] = '\0';

		return line;
	}
}

//This function will parse the user input and return the number of commands passed in 
int ParseUserInput(char** arguments, char* input) {

	//Initial variables to be used in loops
	char* arg;
	int position = 0;
	
	//strtok() takes the argument and separates it based on the second argument passed in
	//Here we will look for spaces and separate every line based on a space
	arg = strtok(input, " ");
	
	//While there are still argument tokens left over
	while(arg != NULL) {
		
		//Add argument to the argument array
		arguments[position] = strdup(arg);
		//Need to call strtok() again to reset it
		arg = strtok(NULL, " ");
		//Increment position in the array 
		position++;
	}
	
	//Set the last argument to be NULL 
	arguments[position] = NULL;
	//Variable used to count the number of arguments that were passed in
	return position;
}

//This function will remove the redirection and background commands from the argument array
char** changeArgs(char** args, int index, int bg) {

	int i = 0; //iterator 
	char** newArgs = args; //copy the args array into a new array 
	while(args[i] != NULL) { //increment i to find the number of elements 
		i++;
	}
	int j = 0; //second iterator 
	while(j < index) { //while j < index passed into the function 
		newArgs[j] = args[j]; //copy the arguments into the new array 
		j++; //increment j 
	}
	if(bg != 1) { //if we aren't in the background 
		j = j+2; //move j 
		while(j <= i) { 
			newArgs[j-2] = args[j]; //reset elements in array 
			j++; 
		}
		newArgs[i] = NULL; //set the last value to NULL 
	}
	else {
		newArgs[index] = NULL; 
	}
	return newArgs; //return the new string 
}

//This function will be used to implement changing the directory 
//This is one of the built in functions of the shell 
void cd(char* arguments) {
	
	//Variable to be used in loop
	int argLoc;

	//Get the home path of the computer
	char* homePath = (getenv("HOME"));
	
	if(arguments == NULL) {

		//Set directory path to home
		argLoc = chdir(homePath);
		
		//Error handling
		if(argLoc != 0) {
			printf("cd failed %s\n");
			fflush(stdout);
		}
	}

	else {
		//Set the directory path to the next passed in argument
		argLoc = chdir(arguments);
		
		//Error handling
		if(argLoc != 0) {
			printf("cd failed %s\n");
			fflush(stdout);
		}
	}
}

//This function will be used to print the status of the program
//This is one of the built in functions of the shell
void ProgramStatus(int status) {

	//Check to see if any processes are running
	//Print the status and flush stdout
	if(WIFEXITED(status)) {
		printf("Exit Value: %d\n", WEXITSTATUS(status));
		fflush(stdout);
	}
	
	//Check to see what signal killsed the process (if necessary)
	else if(WIFSIGNALED(status)) {
		int s = WTERMSIG(status); 
		printf("Process Killed By Signal: %d\n", s);
		fflush(stdout);
	}

}

//This function will be used to exit the program
void ExitProgram(int numPID, pid_t* backgroundPID) {

	//If no background PID are running, we can just exit the program 
	if(numPID == 0) {
		exit(0);
	}
	
	//If background PID are running, kill them and then exit the program 
	else {
		int i;
		for(i = 0; i < numPID; i++) {
			kill(backgroundPID[i], SIGKILL);
		}
	}
}

//This function will be used to exit the program 
void exitProgram(pid_t* pids, int numPID) {

	int i; //iterator 
	for(i = 0; i < numPID; i++) { //iterate through the pid's
		execlp("kill", "kill", "-TERM", pids[i]); //kill the processes 
	}
	free(pids); //free allocated memoory 
	exit(0); //exit the function 
}

//This function will search for '$$'
//This function will then return the PID of the program wherever an instance of '$$' is found
void GetPID(char* argument) {

	//Get the current PID
	int PID = getpid();
	//Create a string to store the PID
	char PIDString[10];
	//Set that string to be all null terminator keys
	memset(PIDString, '\0', 10);
	//Create a string to store the new string including the PID
	char newArg[20];
	//Use sprintf to get the length of the PID
	int PIDLength = sprintf(PIDString, "%d", PID);
	//Search through the argument for "$$" 
	char* flag = strstr(argument, "$$");
	//Find the length of the argument string
	int length = strlen(argument);
	//Get rid of the $$ from the passed in string
	argument[length-2] = 0;
	//Copy the PID to the end of the argument
	strcat(argument, PIDString);
	//Print new string
	printf("%s\n", argument);
	fflush(stdout);

}

//This function will check to see if the argumennt should be performed in FG or BG mode
//If BG mode, the last char in the input array will be &
int BackgroundHandling(char* arguments[], int argCount) {

	//Check to see if we have the & in the argument
	if(arguments[argCount-1][0] == 38) {
		//38 is the ASCII value of &
		return 1;
	}
	else {
		return 0;
	}
}

//This function will check if redirection was used in the argument 
//
int redirectCheck(char** arguments, int val) {

	int i = 0; //iterator 
	while(arguments[i] != NULL) { //iterate through the argument array 
		if((int)arguments[i][0] == val) { //if the command is the desired ascii val
			return i; 
		}
		i++; //iterate i 
	}
	return -1; //return -1 if the command isn't found
}

//This function will be used to redirect input/output when it is passed into the command line
void redirect2(char** arguments, int Background) {

	//Initialize variables 
	int sourceFD; //source file descriptor  
	int targetFD; //target file descriptor
	int result; 
	int input = redirectCheck(arguments, 60); //60 is ascii value for '<'
	int output = redirectCheck(arguments, 62); //62 is ascii value for '>'
	//int background = redirectCheck(arguments, 38); //38 is ascii value for '&'
	char** newArgs; 
	
	if(input > 0) { //if there is input redirection
		sourceFD = open(arguments[input+1], O_RDONLY); //open the next arg in read only 
		arguments = changeArgs(arguments, input, 0);
		if(sourceFD == -1) { //error handling 
			printf("Can't open %s for input redirection\n", arguments[input+1]);
			fflush(stdout); 
			exit(1); 
		}
		result = dup2(sourceFD, 0); //redirect stdin to the source file 
		if(result == -1) { //error handling 
			perror("Error with dup2()\n"); 
			fflush(stdout);
			exit(2); 
		}
		fcntl(sourceFD, F_SETFD, FD_CLOEXEC); //close the file 
	}
	else if(Background > 0 && arguments[Background+1] == NULL) {
		sourceFD = open("/dev/null", O_RDONLY); //redirect to dev/null
		if(sourceFD == -1) { //error handling 
			printf("Can't open /dev/null for redirection\n"); 
			fflush(stdout); 
			exit(1);
		}
		result = dup2(sourceFD, 0); //redirect the input 
		if(result == -1) { //error handling 
			perror("Error with dup2()\n"); 
			fflush(stdout);
			exit(2); 
		}
	}
	if(output > 0) { //if there is output redirection 
		targetFD = open(arguments[output+1], O_WRONLY | O_CREAT | O_TRUNC, 0644); //open the next argument with the specified permissions 
		arguments = changeArgs(arguments, output, 0); 
		if(targetFD == -1) { //error handling 
			printf("Can't open %s for output redirection\n", arguments[output+1]); 
			fflush(stdout); 
			exit(1); 
		}
		result = dup2(targetFD, 1); //redirect stdout to the output file 
		if(result == -1) { //error handling 
			perror("Error with dup2()\n"); 
			exit(2); 
		}
		fcntl(targetFD, F_SETFD, FD_CLOEXEC); //close the file 
	}
	else if(Background > 0 && arguments[Background+1] == NULL) {
		targetFD = open("/dev/null", O_WRONLY | O_CREAT | O_TRUNC, 0644); //open the next argument with the specified permissions 
		if(targetFD == -1) { //error handling 
			printf("Can't open /dev/null for redirection\n"); 
			fflush(stdout);
			exit(1); 
		}
		result = dup2(targetFD, 1); //redirect the output 
		if(result == -1) { //error handling 
			perror("Error with dup2()\n"); 
			fflush(stdout); 
			exit(1); 
		}
	}
	execvp(arguments[0], arguments); //execute the command passed into the command line
	perror("CHILD: exec failure\n"); //error handling 
	exit(1); 

}
	 
//This function will handle non-built in commands
//Modeled from code provided in Lecture 3.1 of Block 3
void HandleOtherProcesses(char** arguments, int numPID, pid_t* backgroundPID, int status, int argCount, char* InputFile, char* OutputFile, int Background) {
	//add conditional including BackGroundHandling function
	
	//Initialize variables to be used in the loop 
	pid_t spawnPID = -5;
	int ExitPID;
	int index = 0; 

	int i; //iterator 
	for(i = 0; i < argCount; i++) { //iterate through arguments 
		if(strcmp(arguments[i], "&") == 0) { //check for the '&' argument 
			Background = 1; //set the background 
			arguments[i] = NULL; //remove the '&' from the array 
			//printf("Background: %d\n", Background); 
		}
	}

	//Fork the spawnPID
	spawnPID = fork();

	//Case statement for spawnPID
	switch(spawnPID) {
		
		//If the process fails, execute the following
		case -1: {
			perror("Hull Breach!\n");
			fflush(stdout);
			exit(1);
			break;
		}

		case 0: { //child process

			struct sigaction SIGTSTP_action = {0};
			SIGTSTP_action.sa_handler = SIG_IGN;
			backgroundPID[index] = getpid(); 
			index++; 
			
			if(Background > 0 && arguments[Background+1] == NULL) {
				printf("Background PID: %d\n", getpid()); 
				fflush(stdout); 
			}	

			//Redirect arguments
			redirect2(arguments, Background);
			break; 
		}

		default: { //parent process 
			
			//If we are in foreground mode:
			if(Background == 0) {

				//Use waitpid
				ExitPID = waitpid(spawnPID, &status, 0);
				//Check to see what killed the process
				if((WIFSIGNALED(status) && (ExitPID > 0))) {
					printf("Process killed by: %d\n", WTERMSIG(status));
					fflush(stdout);
				}
				else {  
					fflush(stdout); 
					backgroundPID[numPID] = spawnPID; //add the pid to the pid array 
					numPID++; //increment number of pid's 
				}
			break;
			}		
		}
		if(spawnPID == 0) { //check spawnpid
			exit(0); 
		}
		int i; //iterator 
		for(i = 0; i < numPID; i++) { //iterate through the pid's in the array 
			spawnPID = waitpid(backgroundPID[i], &status, WNOHANG); //call waitpid to check if the bg processes are done 
			//Print the pid and its status 
			if(spawnPID > 0) {
				printf("Background PID %d is done: exit val %d\n", backgroundPID[i], status); 
				fflush(stdout); 
				
				//Print the exit value 
				if(WIFEXITED(status)) {
					printf("Exit Value: %d\n", WEXITSTATUS(status));
					fflush(stdout); 
				}
				//Print the signal if it was killed by one 
				else if(WIFSIGNALED(status)) {
					printf("Process killed by a signal: %d\n", WTERMSIG(status));
					fflush(stdout);
				}
			}
		}
	}
}

//This function will check to see if BG processes are still running 
void checkBG(pid_t* pids, int numPID, int childStatus) {

	int i; //iterator 
	for(i = 0; i < numPID; i++) { //iterate through the background processes 
		pid_t childpid = waitpid(pids[i], childStatus, WNOHANG); 
		if(childpid > 0) { //if there are child pid's
			printf("Background PID %d is done:\n", childpid); //print the process 
			ProgramStatus(childStatus); //print the exit status
			fflush(stdout); //flush stdout 
		}
	}
}


//This function will handle the built in commands called by the user
//Built in commands include the following:
//cd
//status
//exit
//Comments (#) and blank lines
void BuiltInCommands(char** arguments, int numPID, pid_t* backgroundPID, int status, int argCount, char* InputFile, char* OutputFile, int Background) {

	int i = 0, j = 0;
	//Iterate through the arguments array and look for "$$"
	for(i = 0; i < argCount; i++) {
		//If we find "$$", call the GetPID() function
		if(strstr(arguments[i], "$$") != NULL) {
			GetPID(arguments[i]);
		}
	}
	//Handle blank lines and comments
	if(arguments[0] == NULL || *(arguments[0]) == '#') {
		; //continue 
	}
	//If we find "exit" in the arguments array, call the ExitProgram() function
	else if(strcmp(arguments[0], "exit") == 0) {
		exitProgram(backgroundPID, numPID);
	}

	//If we find "cd" in the arguments array, call the cd() function
	else if(strcmp(arguments[0], "cd") == 0) {
		cd(arguments[1]);
	}
	
	//If we find "status" in the arguments array, call the ProgramStatus() function
	else if(strcmp(arguments[0], "status") == 0) {
		ProgramStatus(status);
	}
	//Otherwise we will use Redirect() and HandleOtherProcesses() 	
	else {
		HandleOtherProcesses(arguments, numPID, backgroundPID, status, argCount, InputFile, OutputFile, Background);
	}
}

int main(int argc, char** argv) {

	//Initialize variables to be used in functions
	char cwd[MAX_CHARACTERS];
	char** arguments = malloc(MAX_CHARACTERS*sizeof(char));
	char* FileIn;
	char* FileOut;
	int status = 0;
	char* input;
	int argCount = 0;
	int childStatusFG = 0; 
	int childStatusBG = 0; 

	//Initialize refrence variables for foreground/background
	int foreground = 0;
	int background = 0;

	//Initialize strings to represent file names
	char *InputFile = NULL;
	char* OutputFile = NULL;
	
	//Array of processes to store background processes
	int numPID = 0;
	pid_t* backgroundPID = malloc(500*sizeof(pid_t));

	//Initialize signal handlers for CTRL-C and CTRL-Z
	//Modeled from notes in Lecture 3.3
	struct sigaction SIGINT_action = {0};
	struct sigaction SIGTSTP_action = {0};

	//Initialize SIGINT handler
	//We wish to ignore these types of signals in this program 
	SIGINT_action.sa_handler = SIG_IGN;
	//sigfillset(&SIGINT_action.sa_mask);
	//SIGINT_action.sa_flags = 0;
	sigaction(SIGINT, &SIGINT_action, NULL);

	//Initialize SIGTSTP handler
	SIGTSTP_action.sa_handler = catchSIGTSTP;
	sigfillset(&SIGTSTP_action.sa_mask);
	SIGTSTP_action.sa_flags = 0;
	sigaction(SIGINT, &SIGTSTP_action, NULL);	

	while(1) { //run the shell
		//checkBG(backgroundPID, numPID, childStatusBG); 
		input = GetUserInput(); 
		//char** newArgs = getArgs(arguments, input); 
		argCount = ParseUserInput(arguments, input); 
		BuiltInCommands(arguments, numPID, backgroundPID, status, argCount, InputFile, OutputFile, background); 
	}
	return 0;
}
