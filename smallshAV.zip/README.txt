Notes:

Signal handling doesn't work, for some reason CTRL-C does what CTRL-Z should be doing. Additionally, my output redirection is acting up and not working. 
The grading script will likely hang on the last portion of the grading script, I have been using CTRL-Z to exit out of it but other than the last one, it is returning the expected values for the majority of the script 

Instructions to Compile:
gcc -o smallsh smallsh.c
