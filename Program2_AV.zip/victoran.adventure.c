/*
** CS 344 Program 2
** File: adventure
** Author: Andrew Victor
** Date: October 29th, 2019
** This is a modified version of the code I wrote when I took the class Winter 2019
*/ 

#include <stdlib.h>
#include <stdio.h>
#include <string.h> 
#include <time.h>
#include <pthread.h>
#include <fcntl.h> 
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

//Same struct from the buildrooms.c program 
struct Room {
	
	char name[9]; 
	int connections;
	char room_type[11];
	char roomConnections[6][11];
} roomArray[7]; 

//Initialize the mutex that will be used
pthread_mutex_t adventureMutex = PTHREAD_MUTEX_INITIALIZER; 

//Function that will find the most recently created rooms directory 
char* ReadDirectory() {
	
	int newDirTime = -1; //timestamp of the most recently created sub directory 
	char targetDir[32] = "victoran.rooms."; //prefix of the directory that we are searching for 
	char* newDir = malloc(256*sizeof(char)); //string to hold the name of the most recent directory containing the prefix 
	memset(newDir, '\0', sizeof(newDir)); //set the string to be filled with null terminators 
	DIR* checkDir; //directory that we are starting in 
	struct dirent *InDir; //struct used to find information about the directory we are navigating 
	struct stat dirStats; //struct used to find information about a file/directory 
	
	checkDir = opendir("."); //open the directory stream we are in 
	if(checkDir > 0) { //verify that the directory opens successfully 
		while((InDir = readdir(checkDir)) != NULL) { //read through each entry of the directory 
			if(strstr(InDir->d_name, targetDir) != NULL) { //check the directory for the directory with the desired prefix 
				stat(InDir->d_name, &dirStats); //get the information from the directory using stat and store in the struct 
				if((int)dirStats.st_mtime > newDirTime) { //check to see if the time stamp needs to be modified 
					newDirTime = (int)dirStats.st_mtime; //set the new directory time to the time the found directory was last modified 
					memset(newDir, '\0', sizeof(newDir)); //set the newDir string to contain all null terminators for next use 
					strcpy(newDir, InDir->d_name); //set the name of the directory struct to all null terminators for next use 
				}
			}
		}
	}
	
	closedir(checkDir); //close the directory that was originally opened 
	return newDir; //return the most recent found directory
	free(newDir); //free the memory for the directory 
}

//Function that will populate the roomArray struct from the directory that was created 
void FillRooms(char* dir) {
	
	DIR* gameDir = opendir(dir); //open the directory that was found in the ReadDirectory() function 
	struct dirent *filesToRead; //create a struct that will be used to read in files from the directory 
	char* line = NULL; //string that will be used to read in lines of the file 
	//size_t length = 0; //unsigned data type used to hold the length of the file 
	//ssize_t readLine; //signed data type used to read the files 
	int i = 0; //iterator 
	
	while((filesToRead = readdir(gameDir)) != NULL) { //while there is still information in the game directory to be read
		if(strcmp(filesToRead->d_name, ".") == 0 || strcmp(filesToRead->d_name, "..") == 0) { //check to see if the directory is valid 
			int garbage = 0; //need this for the conditional 
			continue; 
		}
		else { //make sure that we are accessing the correct directory 
			char tempName[256]; //string to store the name of the directory 
			memset(tempName, '\0', 256); //set the string to contain all null terminators 
			strcpy(tempName, dir); //copy the name of the directory into the string 
			strcat(tempName, "/"); //add a slash to the end of the string 
			strcat(tempName, filesToRead->d_name); //copy the name of the file to the string 
			FILE* newFile = fopen(tempName, "r"); //open a new file using the tempName string and give it reading permissions 
			
			int j = 0; //second iterator 
			char buffer1[256], buffer2[256], buffer3[256]; //buffer strings to get info from theh files 
			fscanf(newFile, "%s %s %s ", buffer1, buffer2, buffer3); //read information from the file into the buffers to get the room name 
			strcpy(roomArray[i].name, buffer3); //get the room name and store it in the room array 
			fscanf(newFile, "%s %s %s ", buffer1, buffer2, buffer3); //read information from the buffers into the files to get the room connections 
			
			while(strcmp(buffer1, "CONNECTION") == 0) { //while the first buffer is reading in connections 
				int count = 0; //counting variable 
				strcpy(roomArray[i].roomConnections[j], buffer3); //copy the connection and store it in the room array 
				fscanf(newFile, "%s %s %s ", buffer1, buffer2, buffer3); //keep reading the file for more connections 
				roomArray[i].connections++; //increment the number of connections when a new one is added 
				j++; //increment the second iterator 
				count++; //increment the count variable 
			}
			
			fscanf(newFile, "%s %s %s ", buffer1, buffer2, buffer3); //read information in the file to get the room type 
			strcpy(roomArray[i].room_type, buffer3); //copy the room type and store in the room array 
			fclose(newFile); //close the file that we have been manipulating 
			i++; //increment first iterator 
		}
	}
	closedir(gameDir); //close the game directory 
}

//Function that will get and return the index of the start room in the room array 
int GetStartRoom() {
	
	int i = 0; //iterator 
	for(i = 0; i < 7; i++) { //iterate through all of the rooms in the array 
		if(strcmp(roomArray[i].room_type, "START_ROOM") == 0) { //find which room has the start room type 
			return i; //return the index of the start room 
		}
	}
}
	
//Function that will get and return the index of the end room in the room array 
int GetEndRoom() {
	
	int i = 0; //iterator 
	for(i = 0; i < 7; i++) { //iterate through all of the rooms in the array 
		if(strcmp(roomArray[i].room_type, "END_ROOM") == 0) { //find which room has the end room type 
			return i; //return the index of the end room 
		}
	}
}

//Function that will return the index of the next room (to be used in the RunGame() function)
int GetNewRoom(char string[]) {
	
	int i = 0; //iterator 
	for(i = 0; i < 7; i++) { //iterate through all of the possible rooms 
		if(strcmp(string, roomArray[i].name) == 0) { //check to see if the input matches one of the room names 
			return i; //return the index of the next room 
		}
	}
}

//Function that will display the current room to the user 
void DisplayRoom(int index) {
	
	int i; //iterator 
	printf("\n"); //proper formatting for getting user input 
	printf("CURRENT LOCATION: %s\n", roomArray[index].name); //print the current location 
	printf("POSSIBLE CONNECTIONS: "); //print according to assignment format 
	for(i = 0; i < roomArray[index].connections-1; i++) { //loop through the connections in the room 
		printf("%s, ", roomArray[index].roomConnections[i]); //print the connections for the room (comma separated)
	}
	printf("%s.", roomArray[index].roomConnections[roomArray[index].connections-1]); //print the last connection (ends with a period)
	printf("\n"); //print a newline for assignment formatting 
	printf("WHERE TO? >"); //print this for assignment formatting 
}

//Function that will check for valid user input 
int CheckUserInput(int index) {
	
	int i = 0; //iterator 
	char input[256]; //input string 
	memset(input, '\0', 256); //set the input string to be all null terminators 
	scanf("%s", input); //get input from the user 
	
	for(i = 0; i < roomArray[index].connections; i++) { //loop through the number of connections in the current room 
		if(strcmp(input, roomArray[index].roomConnections[i]) == 0) { //check to see if the input matches one of the possible connections 
			return i; //return the index of the connection 
		}
	}
	
	if(strcmp(input, "time") == 0) { //check to see if the user inputs "time"
		return 7; //return this value to be used later
	}
	
	return -3; //return this value if there isn't a valid input 
}

//Function that will write the current time to a file specified in the assignment 
//Function is void* with a void* argument to fit the parameters of pthread_create 
void* WriteTime(void* argument) {
	
	char buffer[256]; //create a string to represent the buffer 
	pthread_mutex_lock(&adventureMutex); //lock the mutex for the game  
	FILE* timeFile = fopen("currentTime.txt", "w"); //create a file and give it writing permissions 
	time_t currTime; //variable to represent the current time 
	struct tm *timeInfo; //struct to represent the information about the current time 
	time(&currTime); //get the time and set it to the currTime variable 
	timeInfo = localtime(&currTime); //set the current time to the local time in the time struct 
	strftime(buffer, sizeof(buffer), "%I:%M%p, %A, %B, %d, %Y", timeInfo); //parse the time as specified in the assignment 
	fprintf(timeFile, "%s\n", buffer); //print the time to the time file 
	fclose(timeFile); //close the time file 
	pthread_mutex_unlock(&adventureMutex); //unlock the mutex 
}

//Function that will print the time from the time file to the screen for the user 
void PrintTime() {
	
	FILE *timeFile = fopen("currentTime.txt", "r"); //open the time file that was generated with reading permissions 
	char buffer[256]; //create a string to store the time in 
	//memset(buffer, '\0', 256); //set the string to contain all null terminators 
	fgets(buffer, 256, timeFile); //get the first line of the time file 
	printf("\n%s", buffer); //print the time on the screen 
	fclose(timeFile); //close the time file 
}

//Function that will be used to run the adventure game 
void RunGame() {
	
	pthread_t timeThread; //create a thread for time
	pthread_mutex_lock(&adventureMutex); //lock the adventure mutex 
	pthread_create(&timeThread, NULL, WriteTime, NULL); //create a thread for time 
		
	int start = GetStartRoom(); //get the index of the starting room 
	int curr = start; //save the index to be used later 
	int end = GetEndRoom(); //get the index of the ending room 
	int numSteps = 0; //used to track the number of steps taken by the player 
	int i = 0, j = 0, k = 0; //iterators to be used throughout 
	char path[50][10]; //string array to store the path traveled 
	
	printf("CURRENT LOCATION: %s\n", roomArray[start].name); //print the name of the start room with required formatting 
	printf("POSSIBLE CONNECTIONS: "); 
	for(i = 0; i < roomArray[start].connections-1; i++) { //iterate through the starting room connections 
		printf("%s, ", roomArray[start].roomConnections[i]); //print the comma separated room connections 
	}
	printf("%s.", roomArray[curr].roomConnections[roomArray[start].connections-1]); //print the connection that ends with a period 
	printf("\n"); //print a newline for formatting purposes 
	printf("WHERE TO? >"); //print for formatting purposes 
	
	int flag = 0; //boolean variable 
	while(flag == 0) { //continue running the game while the boolean is false 
		int check = CheckUserInput(curr); //get the user input and return the int 
		if(check == 0 || check == 1 || check == 2 || check == 3 || check == 4 || check == 5 || check == 6) { //check for valid input 
			curr = GetNewRoom(roomArray[curr].roomConnections[check]); //reset curr and get the new room 
			strcpy(path[numSteps], roomArray[curr].name); //copy the name of the room into the path 
			numSteps++; //increment the number of steps taken by the user 
			
			if(strcmp(roomArray[curr].room_type, "END_ROOM") == 0) { //check to see if the user has reached the end room 
				printf("\nYOU HAVE FOUND THE END ROOM! CONGRATULATIONS!\n"); //print victory message 
				printf("NUMBER OF STEPS TO VICTORY: %d\n", numSteps); //print the number of steps the user took 
				printf("PATH TO VICTORY: \n"); 
				for(j = 0; j < numSteps; j++) { //iterate through the steps that the user took 
					printf("%s\n", path[j]); //print the path that the user took 
				}
				flag = 1; //set the flag to true so the game ends 
			}
			
			else { //game hasn't ended yet 
				DisplayRoom(curr); //display the next room 
			}
		}
			
		else if(check == 7) { //user input was a request for the current time 
			pthread_mutex_unlock(&adventureMutex); //unlock the adventure mutex 
			pthread_join(timeThread, NULL); //wait for adventureMutex to terminate
			pthread_mutex_lock(&adventureMutex); //lock the adventure mutex once again 
			pthread_create(&timeThread, NULL, WriteTime, NULL); //create a new thread for writing time
			PrintTime(); //print the time 
			DisplayRoom(curr); //display the current room after time has been printed and return to the game  	
		}
			
		else { //error handling for bad input 
				printf("\nHUH!? I DON'T UNDERSTAND THAT PATH, TRY AGAIN\n"); //error message 
				DisplayRoom(curr); //display the room that the user was on before entering bad input 
		}
	}
}

int main() {
	
	srand(time(NULL)); //for time 
	char* directory = ReadDirectory(); //read in the buildrooms directory 
	FillRooms(directory); //generate rooms based on the passed in directory 
	RunGame(); //run the game 

return 0; 
}	
