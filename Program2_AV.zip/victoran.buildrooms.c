/*
** CS 344 Program 2
** File: buildrooms
** Author: Andrew Victor
** Date: October 29th, 2019
** This is a modified version of the code I wrote when I took the class Winter 2019
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>

//Struct to store the Room object
struct Room {
	
	char name[9]; 	//store the name of the room (8 chars + NULL terminator)
	int connections; 	//number of connections that the room has
	char room_type[11]; //store the type of room (10 chars + NULL terminator)
	char roomConnections[6][11]; //array of room connections and names that the room is connected to
} roomArray[7]; 

//Function to get a random room and add it to the roomArray 
struct Room GetRandomRoom() {
	
	int roomPos = rand()%7; //generate a random int between 0 and 6
	return roomArray[roomPos];
}

//Function that will connect two rooms in the connection array 
struct Room ConnectRoom(struct Room a, struct Room b) {
	
	int numConnections = a.connections; //get the number of connections for the first room
	strcpy(a.roomConnections[numConnections], b.name); //copy the name of room b to the list of connections for room a
	a.connections = a.connections+1; //increment the number of connections for room a
	return a;
}

//Function that will check to see if a connection already exists between two rooms
int ConnectionAlreadyExists(struct Room a, struct Room b) {
	
	int i = 0; //iterator
	for(i = 0; i < a.connections; i++) { //iterate through each of a's connections
		if(strcmp(a.roomConnections[i], b.name) == 0) {  //if the name of b matches any of a's connections already 
			return 1; //connection already exists 
		}
	}
	return 0; //no connection exists so we can add a new one
}

//Function that will check to see if two rooms are the same before making a new connection
int IsSameRoom(struct Room a, struct Room b) {
	
	if(strcmp(a.name, b.name) == 0) { //compare the names of the two rooms 
		return 1; //room names are the same, don't add a connection 
	}
	else {
		return 0; //no connection yet, add another
	}
}

//Function to see if a room has reached its max number of connections 
int CanAddConnectionFrom(struct Room a) {
	
	if(a.connections < 6) { //see if the room has reached its max number of connections  
		return 1; //return true if the max number of connections has been reached
	}
	else {
		return 0; //return false otherwise, add a new connection 
	}
}

//Function to add a new room connection between two rooms if valid 
void AddRandomConnection() {
	
	//Create temporary room structs
	struct Room A;
	struct Room B; 

	int flag = 0; //boolean flag set to true 
	
	while(flag == 0) { //while the flag is true 
		A = GetRandomRoom(); //Get a random room and see if connection can be added 
		if(CanAddConnectionFrom(A) == 1) {
			flag = 1; //reset flag, connection cannot be added 
		}
	}
	do { //Get a random room for B while it can have another connection added, A and B aren't the same, and a connection between them doesn't exist 
		B = GetRandomRoom();
	}
	while(CanAddConnectionFrom(B) == 0 || IsSameRoom(A, B) == 1 || ConnectionAlreadyExists(A, B) == 1); 

	A = ConnectRoom(A, B); //Connect Room A to Room B
	B = ConnectRoom(B, A); //Connect Room B to Room A	

	int i; //iterator 
	for(i = 0; i < 7; i++) { //iterate through the rooms and make deep copies of the connections
		if(strcmp(A.name, roomArray[i].name) == 0) { //compare room A to the roomArray 
			roomArray[i].connections = A.connections; //set the number of connections in roomArray to the number of connections in A
			strcpy(roomArray[i].roomConnections[A.connections-1], A.roomConnections[A.connections-1]); //copy connections of the A-1 index to the roomArray, ensure proper indexing 
		}
		//Repeat the above process for room B
		else if(strcmp(B.name, roomArray[i].name) == 0) {
			roomArray[i].connections = B.connections; 
			strcpy(roomArray[i].roomConnections[B.connections-1], B.roomConnections[B.connections-1]); 
		}
	}
}

//Function to test and see if the correct number of connections has been met 
int IsConnectionArrayFull() {
	
	int i = 0; //iterator for while loop
	while(i < 7) {
		if(roomArray[i].connections < 3) { //check to see if the minimum number of connections has been met
			return 0; //return false, can add another connection
		}
		i++; //increment i
	}
	return 1; //return true, minimum number of connections has been met 
}

//Function that will generate the 10 different rooms to be used in the adventure
char** GenerateRooms() {
	
	char** roomNames = malloc(10*sizeof(char*)); //2D array to store the 10 possible names
	int i; //iterator 
	for(i = 0; i < 10; i++) { //iterate through the 10 possible rooms
		roomNames[i] = malloc(256*sizeof(char)); //allocate memory to store the names of the room in the array 
	}
	//Copy the room names into the array (from TPB) 
	strcpy(roomNames[0], "Ricky");
	strcpy(roomNames[1], "Bubbles");
	strcpy(roomNames[2], "Julian");
	strcpy(roomNames[3], "Lahey");
	strcpy(roomNames[4], "Mo");
	strcpy(roomNames[5], "Jacob");
	strcpy(roomNames[6], "Corey");
	strcpy(roomNames[7], "Trevor");
	strcpy(roomNames[8], "Randy");
	strcpy(roomNames[9], "Sarah");
	
	return roomNames; //return the array of names 
} 

//Function to create a directory 
char* CreateDirectory() {
	
	char* directory = malloc(256*sizeof(char)); //allocate memory for a char array to store the direcotry
	strcpy(directory, "victoran.rooms."); //add username to directory for required formatting
	int dir_id = getpid(); //get the process id 
	char p_id[20]; //char array to store the process id 
	sprintf(p_id, "%d", dir_id); //print the process id to the directory in the process id array  
	strcat(directory, p_id); //move the process id to the to the end of the directory array 
	mkdir(directory, 0700); //make the directory, give it access permissions 
	return directory; 
}

//Function to create the files to be used in the adventure 
char** CreateFiles(char* dir, char** files) {
	
	int usedNames[7]; //array to store the numbers of the used names
	int count = 0; //count variable 
	char** roomFiles = malloc(7*sizeof(char*)); //2d char array used to store the numbers and names of the roomfiles array 
	int i, j; //iterators 
	
	for(i = 0; i < 7; i++) {
		roomFiles[i] = malloc(256*sizeof(char)); //allocate memory for each element of the room files array
	}
	
	while(count < 7) { //loop that will run until there are 7 rooms in the array 
		int found = 0; //boolean variable to check if the randomly selected number has already been used 
		do {
			int random = rand()%10; //generate a random int between 0 and 9
			for(j = 0; j < 7; j++) { //loop through the arrays 
				if(usedNames[j] == random) { //check if the random number is in the array 
					found = 1; //set the flag to true and break out of the loop 
					break;
				}
				else {
					found = 0; //keep the flag set to true and create a new file 
				}
			}
		}while(found == 1); 
		
		char tempName[256]; //char to store the temporary name 
		memset(tempName, '\0', 256); //fill the char array with null terminators 
		strcpy(tempName, dir); //copy the name of the room and store it in the directory 
		strcat(tempName, "/"); //add a slash to the end of the name
		strcat(tempName, files[count]); //add the file name 
		FILE* newFile = fopen(tempName, "w"); //create a new file and give it writing permissions 
		count++; //increment the count variable; 
		fclose(newFile); //close the generated file 
	}
}

//Function to be used to fill the array with the created files
/*void FillArray(char** files) {
	
	int i; //iterator
	for(i = 0; i < 7; i++) { //iterate through each of the 7 files 
		strcpy(roomArray[i].name, files[i]); //copy the name of the room, store the file at index i
		roomArray[i].connections = 0; //set the number of connections in each room to 0
		if(i == 0) { //set the first randomly selected value to be the start room
			strcpy(roomArray[i].room_type, "START_ROOM"); 
		}
		else if(i == 1) { //set the second randomly selected room to be the end room 
			strcpy(roomArray[i].room_type, "END_ROOM"); 
		}
		else { //set the rest of the rooms to be a middle room 
			strcpy(roomArray[i].room_type, "MID_ROOM"); 
		}
	}
}*/ 

void FillArray(char** files) {
	
	int i; //iterator 
	int ran = rand()%7; //random int between 0 and 6 
	for(i = 0; i < 7; i++) { //loop through all of the files 
		strcpy(roomArray[i].name, files[i]); //copy the names into the array 
		roomArray[i].connections = 0; //set the connections for each room 
	}
	strcpy(roomArray[ran].room_type, "START_ROOM"); //set the first random index to be the start room 
	ran++; //increment random variable 
	if(ran > 6) { //check if randon int is outside of the bounds of the array 
		ran = 0; //if its outside of the bounds, reset it 
	}
	strcpy(roomArray[ran].room_type, "END_ROOM"); //set the ran+1 index to be the end room 
	ran++; //increment ran
	int j; //iterator 2
	for(j = 0; j < 5; j++) { //loop through the rest of the rooms in the array 
		strcpy(roomArray[ran].room_type, "MID_ROOM"); //set them to be the middle rooms
		ran++; //increment ran
		if(ran > 6) { //check if ran is outside of the bounds of the array 
			ran = 0; //reset it 
		}
	}
}

//Function to be used to write to the files 
void WriteToFiles(char* dir, char** files) {
	
	int i; //iterator 
	for(i = 0; i < 7; i++) { //iterate through each room file 
		char tempFile[256]; //initialize temp file 
		memset(tempFile, '\0', 256); //fill the temp file with null terminators 
		strcpy(tempFile, dir); //copy the directory to the temp file 
		strcat(tempFile, "/"); //add a slash to allow access to the directory 
		strcat(tempFile, files[i]); //add the file name 
		FILE* newFile = fopen(tempFile, "w"); //open the file and give it writing permissions 
		fprintf(newFile, "ROOM NAME: %s\n", roomArray[i].name); //write the room name to the file 
		
		int j; //second iterator 
		for(j = 0; j < roomArray[i].connections; j++) { 
			fprintf(newFile, "CONNECTION %d: %s\n", (j+1), roomArray[i].roomConnections[j]); //print the list of connections 
		}

		fprintf(newFile, "ROOM TYPE: %s\n", roomArray[i].room_type); //write the room type to the file 
		fclose(newFile); //close the file 
	}
}

int main() {
	
	srand(time(NULL));
	char** rooms = GenerateRooms(); //generate the array of rooms
	char* directory = CreateDirectory(); //generate the directory 
	char** roomFiles = CreateFiles(directory, rooms); //create the room files 
	FillArray(rooms); //fill the room array 
	while(IsConnectionArrayFull() == 0) { //add connections while the array isn't full 
		AddRandomConnection(); 
	}
	WriteToFiles(directory, rooms); //write the information generated to the files 
	
	int i; //iterator 
	for(i = 0; i < 10; i++) { //free the dynamically allocated memory for the rooms array 
		free(rooms[i]); 
	}
	free(rooms); //free the rest of the array 
	
	return 0; 
}
