/* 
** Author: Andrew Victor
** Date: November 23rd, 2019
** Program: keygen.c
*/ 

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

//This program will create a key file of specified length input by the user
int main(int argc, char** argv) { 

	srand(time(NULL)); //set a seed to get different numbers each time 

	if(argc != 2) { //error handling 
		perror("Invalid number of arguments\n");
		exit(1); //specified in assignment 
	}

	int keyLength = atoi(argv[1]); //convert the passed in argument into an int
	if(keyLength == 0) { //error handling for valid input
		perror("Second argument must be an integer\n"); 
		exit(1); //specified in assignment 
	}
	char key[keyLength+1]; //create a key string to hold the random characters
	memset(key, '\0', keyLength); //set the key to all null terminators 
	int i; //iterator 
	int val; //value that will be randomized 
	for(i = 0; i < keyLength; i++) { //loop through the specified argument 
		val = rand()%27; //generate a random val between 0-27
		if(val == 26) { //if we get 26, assign it to be a space instead
			val = 32; //ascii for space 
		}
		else { 
			val = val + 65; //add 65 to convert the value to an uppercase letter
		}
		key[i] = (char)val; //pass the char of val into the key array 
	}
	key[keyLength] = '\n'; //set the last element to be a newline 
	printf("%s", key); 

	return 0; 
}
