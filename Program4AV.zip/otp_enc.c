/*
** Author: Andrew Victor
** Date: November 23rd, 2019
** Program: otp_enc.c
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> 
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <fcntl.h>

//The following code is referenced from the client.c code provided in the lecture notes

//This function will be used to report issues 
void error(const char* message) { 
	perror(message);
	exit(0); 
}

//This program will connect to otp_enc_d and ask it to perform a otp encryption 

int main(int argc, char** argv) { 
	
	//Initialize variables to use in the client/host connection 
	int socketFD; //for storing the socket 
	int portNum; //for storing the port 
	int charsWritten; //for storing number of written characters 
	int charsRead; //for storing number of read characters 
	struct sockaddr_in serverAddress; //for the server 
	struct hostent* serverHostInfo; //for the houst 
	char buffer1[501]; //buffer to hold read-in data 
	memset(buffer1, '\0', sizeof(buffer1)); //set first bufffer to all null terminators 
	char buffer2[200000]; //buffer to hold the entire read-in string 
	memset(buffer2, '\0', sizeof(buffer2)); //set second buffer to all null terminators 
	char cipher[100000]; //string to hold the cipher text 
	memset(cipher, '\0', sizeof(cipher)); //set the cipher string to all null terminators 

	//Error handle command line inputs 
	if(argc < 4) { 
		fprintf(stderr, "CORRECT USAGE IS: %s plaintext key port\n", argv[0]); 
		exit(0); 
	} 
	
	//Open passed in arguments and read them 
	int plainFile = open(argv[1], O_RDONLY); //open the plaintext file in read-only
	if(plainFile < 0) { //error handling for bad open() 
		error("CLIENT: problem reading plaintext file\n"); 
	}
	int keyFile = open(argv[2], O_RDONLY); //open the key file in read-only 
	if(keyFile < 0) { //error handling for bad open() 
		error("CLIENT: problem reading key file\n"); 
	} 
	
	//Get the size of the passed in argument files 
	//Code referenced from stack overflow
	//First get the size of the plaintext file using the stat struct 
	struct stat s1; 
	stat(argv[1], &s1); //argv[1] is the plaintext file 
	int plaintextSize = s1.st_size; 
	//Get the size of the key file using the same process 
	struct stat s2;
	stat(argv[2], &s2); //argv[2] is the key file 
	int keySize = s2.st_size; 
	
	//Compare the two sizes to ensure that the key file is at least as large as the plaintext file 
	if(keySize < plaintextSize) { //error handling 
		fprintf(stderr, "CLIENT: key file is too short for the given plaintext\n"); 
		exit(1); 
	} 
	
	//Set up the server address struct 
	memset((char*)&serverAddress, '\0', sizeof(serverAddress)); //clear the address struct 
	portNum = atoi(argv[3]); //Get the port number, convert to an int from str 
	serverAddress.sin_family = AF_INET; //create a network-capable socket 
	serverAddress.sin_port = htons(portNum); //store the port number 
	serverHostInfo = gethostbyname("localhost"); //Set the host to "localhost" 
	if(serverHostInfo == NULL ) { //error handling 
		fprintf(stderr, "CLIENT: ERROR, no such host\n"); 
		exit(0); 
	}
	memcpy((char*)&serverAddress.sin_addr.s_addr, (char*)serverHostInfo->h_addr, serverHostInfo->h_length); //copy the address 

	//Set up the socket 
	socketFD = socket(AF_INET, SOCK_STREAM, 0); //create the socket 
	if(socketFD < 0) { //error handling socket() 
		error("CLIENT: ERROR opening socket\n"); 
	}
	//Connect to the server 
	if(connect(socketFD, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0) //connect the socket to the address 
		error("CLIENT: ERROR connecting to server\n"); 
	
	//Perform the "handshake" with the server
	memset(buffer1, '\0', sizeof(buffer1)); //set the buffer to be all NULL terminators  
	strcpy(buffer1, "encoder"); //copy this message into the buffer 
	charsWritten = send(socketFD, buffer1, sizeof(buffer1)-1, 0); //send the message to the server
	//printf("sent encoder to server\n");  
	if(charsWritten < 0) { //error handling for bad send() 
		error("CLIENT: ERROR writing to the socket\n");  
	}
	if(charsWritten < strlen(buffer1)) { //error handling for incomplete send() 
		printf("CLIENT: WARNING: Not all data was written to the socket\n"); 
	}
	
	//Receive message from the client that determines if the connection was successful or not 
	memset(buffer1, '\0', sizeof(buffer1)); //reset buffer1 to all null terminators
	charsRead = recv(socketFD, buffer1, sizeof(buffer1)-1, 0); //receive the data 
	if(charsRead < 0) { //error handling for bad recv() 
		error("CLIENT: ERROR reading from the socket\n");  
	}
	if(strcmp(buffer1, "encoder") != 0) { //error handling for bad connection 
		fprintf(stderr, "CLIENT: otp_enc can't connect to otp_enc_d, the connection will be terminated\n"); 
		exit(2); //specified exit status 
	}
	//printf("received successful connection from server\n"); 
	fflush(stdout); //flush stdout for next output 
	memset(buffer1, '\0', sizeof(buffer1)); //reset buffer1 to all null terminators 
	
	//Read in the plaintext file in chunks of 500 characters 
	//printf("trying to read plaintext\n"); 
	while(read(plainFile, buffer1, 500) > 0) { //read 500 chars at a time 
		int i = 0; //iterator 
		char validChar; //char to represent passed in characters from the plaintext file
		for(i = 0; i < strlen(buffer1); i++) { //iterate through the buffer 
			validChar = buffer1[i]; //set the check to the current index of the plaintext file  
			//Check for bad chars in the plaintext file 
			if((int)validChar < 65 || (int)validChar > 90) { //make sure the char is uppercase 
				if((int)validChar != 13 && (int)validChar != 10 && (int)validChar != 32) { //make sure the char is a newline, space, or line carriage 
					fprintf(stderr, "ERROR: CLIENT: bad characters in plaintext file\n"); 
					exit(1); //specified exit status 
				}
			}
		}
		//After checking for bad characters, check for the '\n' at the end of the file 
		if(strcspn(buffer1, "\n") != 500) { //look for the '\n' character 
			buffer1[strcspn(buffer1, "\n")] = '#'; //if the newline char is found, replace it with a '#' for parsing 
			strcat(buffer1, "#"); //add another '#' to the end of the buffer1 string for parsing 
		}
		//buffer2 should now read "plaintext"##
		strcat(buffer2, buffer1); //append buffer1 to the larger buffer2 
		memset(buffer1, '\0', sizeof(buffer1)); //reset buffer1 for next use 
	}
	
	//printf("read in plaintext\n"); 
	fflush(stdout); //flush stdout for next output 
	
	//Repeat the same above process for the key file 
	//Read in the key file in chunks of 500 chars 
	//printf("trying to read in key\n"); 
	while(read(keyFile, buffer1, 500) > 0) { //read 500 chars at a time 
		int j = 0; //iterator 
		char validKey; //char to represent characters passed in from key file 
		for(j = 0; j < strlen(buffer1); j++) { //iterate through the buffer 
			validKey = buffer1[j]; //set the check to the current index of the key file 
			//Check for bad chars in the key file 
			if((int)validKey < 65 || (int)validKey > 90) { //make sure the char is uppercase 
				if((int)validKey != 13 && (int)validKey != 10 && (int)validKey != 32) { //make sure the char is a newline, space, or line carriage 
					fprintf(stderr, "ERROR: CLIENT: bad characters in key file\n"); 
					exit(1); //specified exit status 
				}
			}
		}
		//After checking for bad characters, check for the '\n' at the end of the file 
		if(strcspn(buffer1, "\n") != 500) { //look for '\n'
			buffer1[strcspn(buffer1, "\n")] = '%'; //if the \n is found, replace it with a '%' for parsing 
			strcat(buffer1, "%"); //add another '%' to tne end of the buffer1 string for parsing 
		}
		strcat(buffer2, buffer1); //append buffer1 to the larger buffer2 
		memset(buffer1, '\0', sizeof(buffer1)); //reset buffer1 for next use
	}
	//printf("read in key\n"); 
	fflush(stdout); 
	//buffer2 nows reads "plaintext"##"key"%%
	//Need to send buffer2 to the server 500 chars at a time 
	int sent = 0; //count variable for loop 
	//printf("trying to send plaintext to server\n"); 
	do{ 
		memset(buffer1, '\0', sizeof(buffer1)); //reset buffer1 for next use 
		strncpy(buffer1, buffer2+sent, 500); //copy the first 500 chars from buffer2 into buffer1 
		sent = sent + 500; //increment sent for the next use 
		charsWritten = send(socketFD, buffer1, strlen(buffer1), 0); //send the data to the server 
		//printf("sending plaintext##key%% to server\n"); 
		if(charsWritten < 0) { //error handling for bad send() 
			error("CLIENT: ERROR writing to the socket\n");  
		}
		if(charsWritten < strlen(buffer1)) { //error handling for incomplete send() 
			printf("CLIENT: WARNING: Not all data has been written to the socket\n"); 
		}
	} while(sent < strlen(buffer2)); //run while there is still data in buffer2 to be sent 
	//printf("sent plaintext and key to server\n"); 
	fflush(stdout); 	
	//Receive the encrypted text back from the server 
	//printf("trying to receive encrypted text from server\n"); 
	do { 
		memset(buffer1, '\0', sizeof(buffer1)); //reset the buffer for next use 
		charsRead = recv(socketFD, buffer1, sizeof(buffer1)-1, 0); //read the data from the server 
		//printf("receiving encrypted data from server\n"); 
		if(charsRead < 0) { //error handling for bad recv() 
			error("CLIENT: ERROR reading from the socket\n"); 
		}
		strncat(cipher, buffer1, strcspn(buffer1, "##")); //read the data into the cipher string until '##' is found 
	} while(strstr(buffer1, "##") == NULL); //run until the '##' special characters are received 
	//printf("received encrypted text\n"); 
	fflush(stdout); 	
	//Print the encrypted text 
	printf("%s\n", cipher); 
	close(socketFD); //close the socket connection 	
	return 0;
}

