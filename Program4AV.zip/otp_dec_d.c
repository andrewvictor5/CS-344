/*
** Author: Andrew Victor
** Date: November 23rd, 2019
** Program: otp_dec_d.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>

//This program will run in the background as a daemon and connect to otp_dec

//Error handling function 
void error(const char* message) { 
	perror(message); 
	exit(1); 
}

//This code is modified from the provided code in Lecture 4.3 - Servers 
int main(int argc, char** argv) { 
	
	//Declare initial variables to be used 
	int listenSocketFD = 0; //for the socket  
	int establishedConnectionFD = 0; //for the connection 
	int portNum = 0; //for the port number 
	int charsRead = 0; //for read-in data 
	socklen_t sizeOfClientInfo; 
	char buffer1[501]; //first buffer 
	memset(buffer1, '\0', sizeof(buffer1)); //set the buffer to be all null terminators 
	char buffer2[300000]; //second buffer 
	memset(buffer2, '\0', sizeof(buffer2)); //set the buffer to be all null terminators 
	struct sockaddr_in serverAddress; 
	struct sockaddr_in clientAddress; 
	
	//Define strings to hold in the data/info that is sent from the client 
	char plainText[100000]; //string for the plaintext file 
	memset(plainText, '\0', sizeof(plainText)); //set the string to be all NULL terminators 
	char keyText[100000]; //string for the key file 
	memset(keyText, '\0', sizeof(keyText)); //set the string to be all null terminators 
	char cipherText[200000]; //string for cipher text 
	memset(cipherText, '\0', sizeof(cipherText)); //set the string to be all null terminators

	//Define variables to be used for child processes 
	//The assignment specifies that we need to be able to handle 5 concurrent connections 
	int childExit = 0; //exit status for the child process 
	int spawnPids[100]; //array of child processes that will be checked in an loop 
	int numPids = 0; //number of child processes 
	
	//Error handle input arguments 
	if(argc < 2) { //not enough input arguments 
		fprintf(stderr, "CORRECT USAGE IS: %s port\n", argv[0]); //error message 
		exit(1); //specified exit status 
	}
	
	//Set up the address struct for the server 
	memset((char *)&serverAddress, '\0', sizeof(serverAddress)); //clear the address struct 
	portNum = atoi(argv[1]); //get the port number and convert it into an integer from a string 
	serverAddress.sin_family = AF_INET; //create a network-capable socket 
	serverAddress.sin_port = htons(portNum); //store the port number 
	serverAddress.sin_addr.s_addr = INADDR_ANY; //any address is allowed for connection to this particular process 

	//Set up the socket 
	listenSocketFD = socket(AF_INET, SOCK_STREAM, 0); //create the socket 
	if(listenSocketFD < 0) { //error handling bad socket() call 
		error("ERROR: opening socket\n"); 
	}
	
	//Enable the socket to begin listening 
	if(bind(listenSocketFD, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) < 0) { //connect the socket to the port 
		error("ERROR: binding socket\n"); 
	}
	listen(listenSocketFD, 5); //turn the socket on, it can now receive up to 5 connections 
	
	//Use an infinite loop to look for new connections 
	while(1) { 
		int i = 0; //iterator 
		//Check to see if the child processes have completed 
		for(i = 0; i < numPids; i++) { 
			spawnPids[i] = waitpid(spawnPids[i], &childExit, WNOHANG); //wait for the process to exit 
		}
		//Accept a new connection 
		sizeOfClientInfo = sizeof(clientAddress); //get the size of the address for the server 
		establishedConnectionFD = accept(listenSocketFD, (struct sockaddr *)&clientAddress, &sizeOfClientInfo); //accept the connection 
		if(establishedConnectionFD < 0) { //error handling for bad accept() call 
			error("ERROR: accepting new connection");
		}
		spawnPids[numPids] = fork(); //fork the new connection so the child process does the decryption 
		//Switch statement for fork() call 
		switch(spawnPids[numPids]) { 
			//Error case 
			case -1: { 
				error("SERVER: HULL BREACH!\n"); //error on fork() call 
			}
			//Child case 
			case 0: {
				//Perform the "handshake" with the client to make sure it is connecting to otp_dec
				//Reset all strings to be null terminators for next use 
				memset(keyText, '\0', sizeof(keyText)); 
				memset(plainText, '\0', sizeof(plainText)); 
				memset(cipherText, '\0', sizeof(cipherText)); 
				memset(buffer1, '\0', sizeof(buffer1)); 
				//Read the message from the connectiong socket, looking for the message "decoder" 
				charsRead = recv(establishedConnectionFD, buffer1, sizeof(buffer1)-1, 0); //read in the data 
				//printf("receiving handshake from client\n"); 
				if(charsRead < 0) { //error handling for bad recv() call 
					error("ERROR: reading from the socket\n"); 
				}
				//Check to see if "decoder" was received 
				if(strcmp(buffer1, "decoder") != 0) { //if we don't get the correct message, the wrong client tried to connect 
					charsRead = send(establishedConnectionFD, "bad", 4, 0); //send back the message that leads to unsuccessful connection 
					//printf("sent bad connection message to client\n"); 
					if(charsRead < 0) { //error handling for bad send() 
						error("ERROR: writing to the socket\n"); 
					}
					close(establishedConnectionFD); //close the connection socket 
				}
				else { //if we received the correct message 
					//Send back a success message 
					charsRead = send(establishedConnectionFD, "decoder", 8, 0); 
					if(charsRead < 0) { //error handling for bad send() 
						error("ERROR: writing to the socket\n"); 
					}
					//printf("sent decoder back to the client\n"); 
					//Read in data 500 chars at a time (same rate as it is being sent)
					//Read in the entire "ciphertext"##"key"%%
					//Looking for "%%"
					do { 
						memset(buffer1, '\0', sizeof(buffer1)); //set the small buffer to all null terminators 
						charsRead = recv(establishedConnectionFD, buffer1, 500, 0); //receive the data 
						//printf("receiving ciphertext##key\n"); 
						if(charsRead < 0) { //error handling for bad recv() 
							error("ERROR: reading from the socket\n"); 
						}
						strncat(buffer2, buffer1, strcspn(buffer1, "%%")); //append until "%%" is found, if it isn't, append the entire buffer 
					} while(strstr(buffer1, "%%") == NULL); //look until the special characters are found
					//printf("got out of first do while loop\nnow have ciphertext##key in buffer2\n"); 						
					//Now that we have the entire input string, we need to parse it to separate the plaintext and key 
					//Parse the string, and look for "##" which separates the ciphertext from the key 
					int j = 0; //iterator 
					int buffLength = 0; //int to represent the length of the full argument string 
					int charCount = 0; //int to represent the numbers of chars counted 
					do { 
						memset(buffer1, '\0', sizeof(buffer1)); //set the small buffer to be all NULL terminators 
						strncpy(buffer1, buffer2+charCount, sizeof(buffer1)); //copy the first 500 chars from the full string to the first buffer
						//printf("in second do-while loop\ncopied first 500 chars into small buffer\n");  
						//Check to see if the "##" separator was found 
						if(strstr(buffer1, "##") == NULL) { //check if we DIDN'T find the "##"
							charCount = charCount+500; //increment count so the next 500 chars are grabbed 
							buffLength = 500; //set the length of the buffer
							//printf("didn't find ## yet\n");  
						}
						else { //if we DID find the "##" in the string 
							strncat(cipherText, buffer1, strcspn(buffer1, "##")); //copy all characters up to the "##" into the ciphertext string 
							//printf("found ## and copied all characters into ciphertext\n"); 
							break; //exit the loop 
						}
						strncat(cipherText, buffer1, buffLength); //copy the entire buffer1 string into ciphertext string 
						//printf("copied buffer1 into ciphertext\n"); 
					} while(1); //set as an infinite do-while loop 
					//printf("got out of 2nd do while loop\n"); 
					//Now that we have separated the ciphertext file into its respective string, we need to parse the key 
					//Want to copy everything else over from the large buffer except for the "%%" at the end 
					char* target = strstr(buffer2, "##"); //grab the rest of the buffer that hasn't been separated into the ciphertext string 
					//Want to grab everything in the buffer except for the "##" at the front and the "%%" at the end 
					//Copy target+2 to skip over the first two chars in the string 
					//Copy the length of target-2 to skip over the last two chars in the string 
					strncpy(keyText, target+2, strlen(target)-2); //copy the buffer contents into the keyText string 
					//Now that we have separated the ciphertext and key files into their respective strings, it is time to decode 
					int i = 0; //iterator 
					for(i = 0; i < strlen(cipherText); i++) { //iterate through the length of the ciphertext string 
						//Change spaces to ascii value 64 
						//Check the ciphertext string first 
						if( cipherText[i] == ' ') { //check ciphertext for spaces 
							cipherText[i] = (char)64; //if we find a space, set it to 64
						}
						if(keyText[i] == ' ') { //check keytext for spaces 
							keyText[i] = (char)64; //if we find a space, set it to 64
						}
						int decrypt = cipherText[i] - 64; //convert from uppercase/spaces to 0-26 (spaces should be 0's) 
						decrypt = decrypt - (keyText[i] - 64); //subract the converted key from the decryption 
						if(decrypt < 0) { //error handling provided in the assignment 
							decrypt = decrypt + 26; 
						}
						decrypt = decrypt % 27; //use mod27 as specified in the assignment 
						decrypt = decrypt + 64; //add 64 to convert back to uppercase letters 
						if(decrypt == 64) { //look for 64's 
							decrypt = (char)32; //if we find one, set it back to be a space 
						}
						plainText[i] = (char)decrypt; //store the decrypted value in the plaintext string  
						plainText[i+1] = '#'; //add the speical ending to the plaintext string for parsing 
					}
					plainText[i+1] = '#'; //add the special ending to the plaintext string for parsing 
					//printf("got out of our loop now we have plaintext\n"); 
					//Now that the message has been decoded into plaintext, we send it back to the client 
					//We will send data in chunks of 500 until the "%%" at the end of the file is received 
					int sent = 0; //int to represent the sent data 
					do { 
						memset(buffer1, '\0', sizeof(buffer1)); //set the small buffer to all null terminators 
						strncat(buffer1, plainText+sent, 500); //copy the first 500 chars from plaintext into the buffer 
						sent = sent+500; //increment sent so the next 500 chars are grabed 
						charsRead = send(establishedConnectionFD, buffer1, sizeof(buffer1)-1, 0); //send the data 
						//printf("sending plaintext back to the client\n"); 
						if(charsRead < 0) { //error handling for bad send() 
							error("ERROR: writing to the socket\n"); 
						}
					} while(strstr(buffer1, "#") == NULL); //run until the first "%" is found 
					close(establishedConnectionFD); //close the connection socket 
				}
				exit(0); //terminate child process 
			}
			//Parent Case
			default: { 
				close(establishedConnectionFD); //close the connection socket 
				numPids++; //increment the number of processes for the array 
				break; 
			}
		}
	}
	close(listenSocketFD); //close the listening socket 
	return 0;
}
